#ifndef NODE_H
#define NODE_H
#include <iostream>

using namespace std;

class node
{
public:
    node();
    node(int Coef);
    node(int Coef, int Exp);
    node(const node &copyThis);
    ~node();
    node& operator =(const node& a);



    friend ostream &operator <<(ostream& out, const node& A);//output


    node* next;
    int exponent;
    int coefficent;



};

#endif // NODE_H
