#ifndef LINKEDLIST_H
#define LINKEDLIST_H

class linkedlist
{
public:
    linkedlist();
};

#endif // LINKEDLIST_H
