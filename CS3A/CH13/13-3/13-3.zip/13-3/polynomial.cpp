#include "polynomial.h"
#include "node.h"
#include <cstdlib>
#include <iostream>

using namespace std;

polynomial::polynomial()
{
    head=NULL;
    cursor = NULL;
}
polynomial::~polynomial()
{

}


polynomial operator +(const polynomial &p1, const polynomial &p2)
{
    polynomial p3;
    node* walker1 = p1.head, *walker2 = p2.head, *newTerm;

    while(walker1 != NULL && walker2 != NULL)
    {
        if(walker1->exponent>walker2->exponent)
        {
            newTerm = new node(walker1->coefficent, walker1->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker1 = walker1->next;
        }
        else if(walker1->exponent < walker2->exponent)
        {
            newTerm = new node(walker2->coefficent, walker2->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker2 = walker2->next;
        }
        else if(walker1->exponent == walker2->exponent)
        {
            newTerm = new node(walker1->coefficent+walker2->coefficent, walker1->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker1 = walker1->next;
            walker2 = walker2->next;
        }
        while(!walker1 && walker2 != NULL)
        {
            newTerm = new node(walker2->coefficent, walker2->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker2 = walker2->next;
        }
        while(!walker2 && walker1 != NULL)
        {
            newTerm = new node(walker1->coefficent, walker1->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker1 = walker1->next;
        }

    }
    return p3;
}

polynomial operator -(const polynomial &p1, const polynomial &p2)
{
    polynomial p3;
    node* walker1 = p1.head, *walker2 = p2.head, *newTerm;

    while(walker1 != NULL && walker2 != NULL)
    {
        if(walker1->exponent>walker2->exponent)
        {
            newTerm = new node(walker1->coefficent, walker1->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker1 = walker1->next;
        }
        else if(walker1->exponent < walker2->exponent)
        {
            newTerm = new node(walker2->coefficent*-1, walker2->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker2 = walker2->next;
        }
        else if(walker1->exponent == walker2->exponent)
        {
            newTerm = new node(walker1->coefficent+walker2->coefficent*-1, walker1->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker1 = walker1->next;
            walker2 = walker2->next;
        }
        while(!walker1 && walker2 != NULL)
        {
            newTerm = new node(walker2->coefficent*-1, walker2->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker2 = walker2->next;
        }
        while(!walker2 && walker1 != NULL)
        {
            newTerm = new node(walker1->coefficent, walker1->exponent);

            if(p3.head==NULL)//if no head
                p3.InsertHead(newTerm);
            else
                p3.Append(newTerm);

            walker1 = walker1->next;
        }

    }
    return p3;

}

polynomial operator *(const polynomial &p1, const polynomial &p2)
{
    polynomial p3;
    node* walker1 = p1.head, *walker2 = p2.head, *walker3, *newTerm;

    while(walker1!=NULL)
    {

        while(walker2!=NULL)
        {
            newTerm= new node(walker1->coefficent*walker2->coefficent,walker1->exponent+walker2->exponent);
            cout << "new term = " << *newTerm << endl;

            if(p3.head==NULL)//if no head
            {
                 p3.InsertHead(newTerm);
                 walker3 = p3.head;
                 cout << "inserting head\n\n\n\n";
            }
//            else
//            {
//                cout << "appending - " << *newTerm << endl ;
//                p3.Append(newTerm);
//            }
            else if(walker3 != NULL)
            {
                cout << "in if\n";
                cout << "walker3 = " << *walker3 << endl << endl << endl;

                if(walker3->exponent!=newTerm->exponent)
                {
                    cout << "appending - " << *newTerm << endl ;
                    p3.Append(newTerm);
                }
                else if(walker3->exponent==newTerm->exponent)
                {
                    cout << "same exponent, adding coeffs\n";
                    walker3->coefficent += newTerm->coefficent;
                    cout << "updated term = " << *walker3 << endl;
                }

            }




            walker2=walker2->next;
        }
        walker3=walker3->next;
        walker1=walker1->next;
        walker2=p2.head;

    }
    return p3;




    //    polynomial p;

//    node* awalker = a.head, *bwalker = b.head;

//    while(awalker != NULL)
//    {
//        bwalker = b.head;

//        while(bwalker != NULL)
//        {
//            node* newNode = new node(awalker->coefficent * bwalker->coefficent, awalker->exponent + bwalker->exponent);

//            if(!p.Search(newNode))
//            {
//                p.InsertSorted(newNode);
//            }
//            else
//            {
//                node* originalNode = new node(*(p.Search(newNode)));

//                originalNode->coefficent = newNode->coefficent * originalNode->coefficent;
//                originalNode->exponent = newNode->exponent + originalNode->exponent;
//            }
//        }
//        awalker = awalker->next;
//    }
//    return p;
}




















/*******************
  Name: Append
  Arguments: a node
  Returns none void function
  Description: appends a node to the end of the list
  Notes: not too bad
  *******************/
void polynomial::Append(node *insertThis)
{
    try
    {
        if(insertThis == NULL)
            throw -1;

        if(head == NULL)
            InsertHead(insertThis);
        else
        {
            node* walker = head;

            while (walker!=NULL)
            {
                cursor = walker;
                walker = walker->next;
            }

            cursor->next = insertThis;
            insertThis = cursor;

            cursor = insertThis->next;
        }
    }
    catch(int e)
    {
        cout<<"CAUTION! Number is NULL!"<<endl;
    }
    catch(bool b)
    {
        cout<<"Sorry bob. This is not the function you are looking for."<<endl;
    }
}
/*******************
  Name: InsertHead
  Arguments: a node
  Returns none, void function
  Description: Inserts a new head.
  Notes: not too bad
  *******************/
void polynomial::InsertHead(node *insertThis)
{
    try
    {
        if(insertThis == NULL)
            throw -1;

        insertThis->next = head;
        head=cursor=insertThis;
    }
    catch(int e)
    {
        cout<<"CAUTION! Number is NULL!"<<endl;
    }
    catch(bool b)
    {
        cout<<"Sorry bob. This is not the function you are looking for."<<endl;
    }
}

/*******************
  Name: <<
  Arguments: linked list
  Returns ostream
  Description: outputs a linked list
  Notes: not too bad
  *******************/
ostream& operator <<(ostream& out, polynomial& A)
{
    //cout << "AHEAD = " << *A.head;
    node *walker = A.head;
    while(walker->next != NULL)
    {
        if(walker->next->coefficent > 0)
        {
            out << *walker;
            walker = walker->next;
            cout << "+";
        }
        else if(walker->next->coefficent<0)
        {
            out << *walker;
            walker = walker->next;
        }
        else if(walker->next->coefficent==0)
        {
            out << "+";
            walker = walker->next;
        }

    }
    out << *walker;
    walker=walker->next;
    return out;
}
