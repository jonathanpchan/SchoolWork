#include "queue.h"
Queue::Queue():LinkedList()
{

}

Node* Queue::DeQ()
{

}

Queue::EnQ(Node *n)
{

}
